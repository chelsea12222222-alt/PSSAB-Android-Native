# PSSAB Android WebView build

This variant opens the existing PSSAB-NEWV30 GitHub Pages website inside the Android app:
https://chelsea12222222-alt.github.io/PSSAB-NEWV30/

The app uses Android WebView with JavaScript and DOM storage enabled. Changes deployed to the website can appear in the app without rebuilding the APK, unless the native wrapper itself changes.

Build with Java 17 and Gradle 8.9:
`gradle assembleDebug --no-daemon`
