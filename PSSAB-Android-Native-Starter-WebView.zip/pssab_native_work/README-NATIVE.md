# PSSAB Tanjung Uncang — Android Native Kotlin (Starter 0.1.0)

Paket ini adalah proyek Android Native berbasis Kotlin + Jetpack Compose. Ini bukan WebView. Aset logo dan latar Rumah Bolon diambil dari ZIP PSSAB-NEWV30 yang diberikan.

## Status saat ini
- Struktur proyek Android Gradle/Kotlin sudah dibuat.
- Layar login native dan panggilan Supabase Auth password dibuat.
- Layar setelah login adalah kerangka UI; menu anggota, kartu anggota, jadwal, presensi QR, chat, dokumen, dan pengurus belum tersambung ke tabel/RPC Supabase.
- Daftar anggota baru, lupa password, pengambilan nama profil dari tabel `profiles`, sesi login persisten, dan logout server belum diselesaikan.
- Belum dibangun atau diuji di perangkat Android. Jangan anggap APK siap produksi.

## Konfigurasi Supabase
URL dan public/publishable key disalin dari `config.js` asli ke `app/build.gradle.kts`. Tidak ada service-role key di proyek ini. Jangan memasukkan service-role key ke aplikasi Android. Bila key publik berubah, perbarui dua `buildConfigField` tersebut.

Login memakai endpoint Supabase Auth `/auth/v1/token?grant_type=password`. Jika proyek Supabase mensyaratkan nomor telepon dengan format internasional, masukkan nomor sesuai format yang disetujui proyek. Keberhasilan juga bergantung pada konfigurasi Auth dan akun yang sudah terdaftar.

## Cara membuka/build
1. Ekstrak ZIP ke folder yang mudah ditemukan.
2. Buka folder proyek ini menggunakan Android Studio di komputer, atau IDE Android di perangkat yang mendukung proyek Gradle modern.
3. Gunakan JDK 17 dan Gradle/Android Gradle Plugin yang sesuai; sinkronkan proyek dengan internet.
4. Jalankan `app` pada perangkat untuk menguji login.
5. Untuk APK debug: jalankan tugas Gradle `assembleDebug`; hasil biasanya ada di `app/build/outputs/apk/debug/app-debug.apk`.

Paket ini tidak menyertakan Gradle Wrapper karena file wrapper membutuhkan distribusi/binary Gradle yang belum tersedia di lingkungan ini. Belum ada APK yang dihasilkan.

## Susunan penting
- `app/src/main/java/id/pssab/tanjunguncang/MainActivity.kt` — UI native dan login.
- `app/src/main/res/drawable/` — aset gambar.
- `referensi_web/` — salinan file web PSSAB asal untuk referensi; tidak dijalankan oleh aplikasi native.
