package id.pssab.tanjunguncang

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

private val Maroon = Color(0xFF641016)
private val ButtonMaroon = Color(0xFF8E1017)
private val Gold = Color(0xFFFFD875)
private val Cream = Color(0xFFFFF7E6)
private val Ink = Color(0xFF2B1710)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PssabApp() }
    }
}

@Composable
private fun PssabApp() {
    var accessToken by remember { mutableStateOf<String?>(null) }
    var emailOrPhone by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var userName by remember { mutableStateOf("Anggota") }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var selectedMenu by remember { mutableStateOf("Beranda") }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = lightColorScheme(primary = ButtonMaroon, secondary = Gold, background = Cream)) {
        Box(Modifier.fillMaxSize()) {
            Image(painterResource(R.drawable.rumah_bolon), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Maroon.copy(alpha = 0.72f)))
            if (accessToken == null) {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Image(painterResource(R.drawable.pssab_logo), "Logo PSSAB", Modifier.size(150.dp), contentScale = ContentScale.Fit)
                    Spacer(Modifier.height(8.dp))
                    Text("PUNGUAN SITUMORANG", color = Gold, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text("SIPITU AMA BORU BERE IBEBERE", color = Color.White, fontSize = 13.sp)
                    Text("SEKTOR TANJUNG UNCANG", color = Gold, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(24.dp))
                    Card(colors = CardDefaults.cardColors(containerColor = Cream), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            Text("Masuk ke PSSAB", fontSize = 23.sp, color = Maroon, fontWeight = FontWeight.Bold)
                            Text("Gunakan email atau nomor HP dan password akun yang sudah terdaftar.", color = Ink, fontSize = 13.sp)
                            OutlinedTextField(value = emailOrPhone, onValueChange = { emailOrPhone = it; message = "" }, label = { Text("Email atau No. HP") }, leadingIcon = { Icon(Icons.Default.Person, null) }, singleLine = true, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email))
                            OutlinedTextField(value = password, onValueChange = { password = it; message = "" }, label = { Text("Password") }, leadingIcon = { Icon(Icons.Default.Lock, null) }, visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
                            if (message.isNotBlank()) Text(message, color = ButtonMaroon, fontSize = 13.sp)
                            Button(onClick = {
                                if (emailOrPhone.isBlank() || password.isBlank()) { message = "Isi email/nomor HP dan password terlebih dahulu."; return@Button }
                                loading = true; message = "Menghubungkan ke Supabase…"
                                scope.launch {
                                    val result = withContext(Dispatchers.IO) { SupabaseAuth.login(emailOrPhone.trim(), password) }
                                    loading = false
                                    if (result.first != null) {
                                        accessToken = result.first
                                        userName = result.second.ifBlank { emailOrPhone.substringBefore('@').ifBlank { "Anggota" } }
                                        message = ""
                                    } else message = result.third.ifBlank { "Login gagal. Periksa data akun dan koneksi internet." }
                                }
                            }, enabled = !loading, modifier = Modifier.fillMaxWidth().height(50.dp), colors = ButtonDefaults.buttonColors(containerColor = ButtonMaroon), shape = RoundedCornerShape(14.dp)) {
                                if (loading) CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp) else Text("MASUK", fontWeight = FontWeight.Bold)
                            }
                            Text("Pendaftaran anggota, lupa password, dan fitur lain akan disambungkan pada tahap berikutnya.", color = Ink.copy(alpha = 0.7f), fontSize = 11.sp)
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("HORAS JALA GABE", color = Gold, fontWeight = FontWeight.Bold)
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    Row(Modifier.fillMaxWidth().background(Maroon.copy(alpha = 0.94f)).padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Image(painterResource(R.drawable.pssab_logo), "Logo PSSAB", Modifier.size(54.dp), contentScale = ContentScale.Fit)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) { Text("Horas, $userName 👋", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp); Text("PSSAB Tanjung Uncang", color = Gold, fontSize = 12.sp) }
                        IconButton(onClick = { accessToken = null; password = ""; selectedMenu = "Beranda" }) { Icon(Icons.Default.Logout, "Keluar", tint = Color.White) }
                    }
                    Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(18.dp)) {
                        Text(if (selectedMenu == "Beranda") "Horas, selamat datang!" else selectedMenu, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text("Punguan Situmorang Sipitu Ama Boru Bere Ibebere", color = Gold, fontSize = 13.sp)
                        Spacer(Modifier.height(20.dp))
                        val items = listOf("Anggota" to Icons.Default.Groups, "Kartu Anggota" to Icons.Default.Badge, "Jadwal Ibadah" to Icons.Default.Event, "Presensi" to Icons.Default.QrCode, "Chat" to Icons.Default.Chat, "Dokumen" to Icons.Default.Folder, "Kelola Pengurus" to Icons.Default.AdminPanelSettings)
                        items.chunked(2).forEach { pair -> Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) { pair.forEach { (label, icon) -> Card(onClick = { selectedMenu = label }, modifier = Modifier.weight(1f).padding(bottom = 12.dp), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Cream)) { Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(icon, null, tint = ButtonMaroon, modifier = Modifier.size(32.dp)); Spacer(Modifier.height(8.dp)); Text(label, color = Ink, fontWeight = FontWeight.SemiBold) } } }; if (pair.size == 1) Spacer(Modifier.weight(1f)) } }
                        Card(colors = CardDefaults.cardColors(containerColor = Cream.copy(alpha = 0.96f)), shape = RoundedCornerShape(16.dp)) { Text("Versi awal native. Menu di atas masih berupa kerangka tampilan; data anggota, jadwal, presensi, chat, dan kartu digital belum dihubungkan ke tabel Supabase.", Modifier.padding(16.dp), color = Ink, fontSize = 13.sp) }
                    }
                    NavigationBar(containerColor = Cream) {
                        listOf("Beranda" to Icons.Default.Home, "Anggota" to Icons.Default.Groups, "Jadwal" to Icons.Default.Event, "Lainnya" to Icons.Default.Menu).forEach { (label, icon) -> NavigationBarItem(selected = selectedMenu == label, onClick = { selectedMenu = label }, icon = { Icon(icon, null) }, label = { Text(label) }) }
                    }
                }
            }
        }
    }
}

private object SupabaseAuth {
    private val client = OkHttpClient()
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    // Supabase password auth: accepts email or phone depending on the account's auth setup.
    fun login(identifier: String, password: String): Triple<String?, String, String> {
        return try {
            val key = BuildConfig.SUPABASE_ANON_KEY
            val field = if (identifier.contains("@")) "email" else "phone"
            val payload = JSONObject().put(field, identifier).put("password", password).toString()
            val request = Request.Builder()
                .url(BuildConfig.SUPABASE_URL.trimEnd('/') + "/auth/v1/token?grant_type=password")
                .addHeader("apikey", key)
                .addHeader("Authorization", "Bearer $key")
                .post(payload.toRequestBody(jsonType)).build()
            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                val json = runCatching { JSONObject(body) }.getOrNull()
                if (response.isSuccessful && json != null) {
                    val user = json.optJSONObject("user")
                    val meta = user?.optJSONObject("user_metadata")
                    val name = meta?.optString("name").orEmpty().ifBlank { meta?.optString("full_name").orEmpty() }
                    Triple(json.optString("access_token").takeIf { it.isNotBlank() }, name, "")
                } else {
                    val error = json?.optString("msg").orEmpty().ifBlank { json?.optString("message").orEmpty() }.ifBlank { "Login gagal (HTTP ${response.code})." }
                    Triple(null, "", error)
                }
            }
        } catch (e: Exception) {
            Triple(null, "", "Tidak dapat terhubung. Periksa internet lalu coba lagi.")
        }
    }
}
